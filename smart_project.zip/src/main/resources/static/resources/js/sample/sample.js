"use strict";

$(()=>{
	Sample();
})

export class Sample{
	constructor() {
		console.log('aaaaaaa')
	}
}