package com.smart.project.web.home.act;

import org.springframework.stereotype.Controller;

@Controller
public class HomePageAct {
}
