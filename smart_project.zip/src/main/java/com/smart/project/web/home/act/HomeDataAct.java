package com.smart.project.web.home.act;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeDataAct {
}
